#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>

// Hardware Definitions
#define PIR_PIN 12       // Motion detection
#define BUZZER_PIN 14    // Sound simulation
#define BUTTON_PIN 27    // Manual visitor trigger
#define LED_PIN 26       // Red LED for visitor presence
#define DOOR_UNLOCK_PIN 25 // Door control

// Display Setup
Adafruit_SSD1306 display(128, 64, &Wire, -1);

// Network Configuration
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// HiveMQ Cloud Broker
const char* mqtt_server = "153bf7e0dba64f39b289718d120ff059.s1.eu.hivemq.cloud";
const int mqtt_port = 8883;
const char* mqtt_user = "ianoo";
const char* mqtt_password = "Ian.0713999551";

// MQTT Topics
const char* motion_topic = "doorbell/motion";
const char* button_topic = "doorbell/button";
const char* face_topic = "doorbell/face";
const char* status_topic = "doorbell/status";
const char* simulation_data_topic = "doorbell/simulation/data";
const char* simulation_system_topic = "doorbell/simulation/system";

// System Variables
WiFiClientSecure secureClient;
PubSubClient client(secureClient);
bool faceRecognized = false;
bool visitorPresent = false;
unsigned long lastMotionTime = 0;
const unsigned long debounceDelay = 2000;

void setup() {
  Serial.begin(115200);
  delay(1000);

  // Initialize hardware
  pinMode(PIR_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
  pinMode(DOOR_UNLOCK_PIN, OUTPUT);

  // OLED initialization
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED allocation failed!");
    while (1);
  }
  displayDisplay("System Booting...");

  // Connect to WiFi
  connectToWiFi();

  // Configure MQTT
  secureClient.setInsecure(); // Bypass SSL verification
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(mqttCallback);

  // Connect to MQTT broker
  connectToMQTT();
}

void loop() {
  // Maintain MQTT connection
  if (!client.connected()) {
    reconnectMQTT();
  }
  client.loop();

  // Check for motion
  checkMotion();

  // Check for button press
  checkButton();

  // Update display status
  updateDisplay();

  // Publish simulation data periodically (every 5 seconds)
  static unsigned long lastPublishTime = 0;
  if (millis() - lastPublishTime > 5000) {
    lastPublishTime = millis();
    publishSimulationData();
  }
}

// WiFi Connection
void connectToWiFi() {
  displayDisplay("Connecting to WiFi...");
  WiFi.begin(ssid, password);
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    displayDisplay("Connecting to WiFi...\n" + String(WiFi.status()));
  }
  
  displayDisplay("WiFi Connected!\nIP: " + WiFi.localIP().toString());
  Serial.println("WiFi connected");
  client.publish(simulation_system_topic, "WiFi connected");
}

// MQTT Connection
void connectToMQTT() {
  displayDisplay("Connecting to MQTT...");
  String clientId = "ESP32Doorbell-" + String(random(0xffff), HEX);
  
  if (client.connect(clientId.c_str(), mqtt_user, mqtt_password)) {
    displayDisplay("MQTT Connected!");
    Serial.println("MQTT connected");
    client.publish(simulation_system_topic, "MQTT connected");
    
    // Subscribe to topics
    client.subscribe(status_topic);
  } else {
    displayDisplay("MQTT Failed!\nRC: " + String(client.state()));
    client.publish(simulation_system_topic, "MQTT connection failed");
  }
}

void reconnectMQTT() {
  static unsigned long lastAttempt = 0;
  if (millis() - lastAttempt > 5000) {
    lastAttempt = millis();
    connectToMQTT();
  }
}

// Motion Detection
void checkMotion() {
  if (digitalRead(PIR_PIN) == HIGH && !visitorPresent) {
    visitorPresent = true;
    lastMotionTime = millis();
    digitalWrite(LED_PIN, HIGH);
    
    // Simulate face recognition
    faceRecognized = random(0, 2); // 50% chance
    
    // Publish events
    client.publish(motion_topic, "Motion detected");
    client.publish(face_topic, faceRecognized ? "Face recognized" : "Unknown face");
    
    // Audible alert
    triggerBuzzer();
  }
  
  // Timeout visitor presence
  if (visitorPresent && millis() - lastMotionTime > debounceDelay) {
    visitorPresent = false;
    digitalWrite(LED_PIN, LOW);
    client.publish(motion_topic, "Motion cleared");
  }
}

// Button Handling
void checkButton() {
  if (digitalRead(BUTTON_PIN) == LOW) {
    delay(50); // Debounce
    if (digitalRead(BUTTON_PIN) == LOW) {
      ringDoorbell();
      client.publish(button_topic, "Button pressed");
    }
  }
}

// Sound Effects
void triggerBuzzer() {
  tone(BUZZER_PIN, 1000, 200);
}

void ringDoorbell() {
  for (int i = 0; i < 2; i++) {
    tone(BUZZER_PIN, 1500, 100);
    delay(200);
  }
}

// Display Handling
void displayDisplay(String text) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println(text);
  display.display();
}

void updateDisplay() {
  static unsigned long lastUpdate = 0;
  if (millis() - lastUpdate > 1000) {
    lastUpdate = millis();
    
    String status = "Status:\n";
    status += "WiFi: " + String(WiFi.status() == WL_CONNECTED ? "OK" : "OFF") + "\n";
    status += "MQTT: " + String(client.connected() ? "OK" : "OFF") + "\n";
    status += "Visitor: " + String(visitorPresent ? "YES" : "NO") + "\n";
    status += "Face: " + String(faceRecognized ? "KNOWN" : "UNKNOWN");
    
    displayDisplay(status);
  }
}

// MQTT Callback
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message;
  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  if (strcmp(topic, status_topic) == 0) {
    if (message.equals("UNLOCK")) {
      digitalWrite(DOOR_UNLOCK_PIN, HIGH);
      client.publish(status_topic, "Door unlocked");
      delay(3000);
      digitalWrite(DOOR_UNLOCK_PIN, LOW);
      client.publish(status_topic, "Door locked");
    }
  }
}

// Simulation Data Publisher
void publishSimulationData() {
  // Create a JSON formatted string with all simulation data
  String simulationData = "{";
  simulationData += "\"motion_detected\":" + String(visitorPresent ? "true" : "false") + ",";
  simulationData += "\"face_recognized\":" + String(faceRecognized ? "true" : "false") + ",";
  simulationData += "\"button_pressed\":" + String(digitalRead(BUTTON_PIN) == LOW ? "true" : "false") + ",";
  simulationData += "\"door_status\":" + String(digitalRead(DOOR_UNLOCK_PIN) == HIGH ? "\"unlocked\"" : "\"locked\"") + ",";
  simulationData += "\"wifi_status\":" + String(WiFi.status() == WL_CONNECTED ? "\"connected\"" : "\"disconnected\"") + ",";
  simulationData += "\"mqtt_status\":" + String(client.connected() ? "\"connected\"" : "\"disconnected\"");
  simulationData += "}";

  // Publish the complete simulation data
  if (client.publish(simulation_data_topic, simulationData.c_str())) {
    Serial.println("Simulation data published successfully");
  } else {
    Serial.println("Failed to publish simulation data");
  }
  
  // Publish system status separately
  String systemStatus = "WiFi:" + String(WiFi.status() == WL_CONNECTED ? "OK" : "OFF") + 
                       ", MQTT:" + String(client.connected() ? "OK" : "OFF");
  client.publish(simulation_system_topic, systemStatus.c_str());
}